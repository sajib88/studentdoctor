


  <main class="main-wrapper">


      <section class="content-wrapper">
          <div class="container">
              <div class="row">
                  <div class="col-md-12 pdl">
                      <div class="tab-wrapper row">
                          <!-- Nav tabs -->


                          <!-- Tab panes -->
                          <div class="tab-content">
                              <div role="tabpanel" class="tab-pane active" id="tab1">
                                  <div class="story-content">
                                      <div class="entry-head">
                                          <h3 class="title">About Us</h3>
                                      </div>
                                      <p>We are a vibrant nonprofit organisation of thousands of pre-health, health professional students and practising doctors from around the world. Membership is free.</p>
                                      <p>The educational mission of ForStudentDoctor is to assist and encourage all students through the challenging and complicated healthcare education process and into practice.</p>
                                  </div>


                                  <div class="story-content">
                                      <div class="entry-head">
                                          <h3 class="title">Our Mission</h3>
                                      </div>
                                      <p>We are a vibrant nonprofit organisation of thousands of pre-health, health professional students and practising doctors from around the world. Membership is free.</p>
                                      <p>The educational mission of ForStudentDoctor is to assist and encourage all students through the challenging and complicated healthcare education process and into practice.</p>
                                  </div>



                              </div>


                          </div>

                      </div>
                  </div>

              </div>
          </div><!--container-->
      </section>

  </main>
