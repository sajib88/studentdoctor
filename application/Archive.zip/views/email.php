<!-- Page Title -->
<div id="page-title" class="page-title page-title-1 bg-email dark">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1><i class="ti-layout-menu"></i>Email</h1>
            </div>
            <div class="col-md-6">
                <ol class="breadcrumb">
                    <li><a href="index.html">Home Page</a></li>
                    <li class="active">Email</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- Page Title / End -->
<!-- Content -->
<div id="content">

  <!-- Section -->
  
<section class="section-sm bg-grey">
    <div class="container">
      <div class="row">
          
          <iframe height="800px" width="100%" src="https://www.google.com/"></iframe>

      </div>
    </div>
  </section>


</div>
<!-- Content / End -->
