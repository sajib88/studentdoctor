
<?php /// echo 'test commit';?>
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>studentdoctor.com Application</b>  System | Version 1.3
        </div>
        <strong><a href="<?php echo base_url(); ?>"><b>Copyright © 2010 - 2017 studentdoctor.com </b></a> - </strong> Patent Pending. All Rights Reserved
    </footer>




   
    
  </body>
</html>



    